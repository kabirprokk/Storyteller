'use client';

import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { usePosts } from '@/hooks/usePost';
import { Input } from '@/components/ui/Form';
import { Button } from '@/components/ui/Button';
import { PostCard } from '@/components/PostCard';
import { Card } from '@/components/ui/Card';
import type { PostType } from '@/types';

const categories: { type: PostType; label: string; icon: string }[] = [
  { type: 'story', label: 'Stories', icon: '📖' },
  { type: 'poem', label: 'Poems', icon: '✍️' },
  { type: 'quote', label: 'Quotes', icon: '💬' },
  { type: 'thought', label: 'Thoughts', icon: '💭' },
];

export default function ExplorePage() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const { posts, loading: postsLoading } = usePosts();
  const [selectedCategory, setSelectedCategory] = useState<PostType | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredPosts, setFilteredPosts] = useState(posts);

  // Filter posts based on category and search
  React.useEffect(() => {
    let result = posts;

    if (selectedCategory) {
      result = result.filter((post) => post.type === selectedCategory);
    }

    if (searchTerm) {
      result = result.filter(
        (post) =>
          post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
          post.tags?.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    setFilteredPosts(result);
  }, [posts, selectedCategory, searchTerm]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full mx-auto mb-4"
          />
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold">Explore</h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Discover stories, poems, and thoughts from our community
              </p>
            </div>
            {user && (
              <Link href="/create">
                <Button>
                  <Plus size={18} />
                  Create Post
                </Button>
              </Link>
            )}
          </div>

          {/* Search Bar */}
          <div className="flex gap-2 mb-4">
            <div className="flex-1">
              <Input
                placeholder="Search posts, tags, authors..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                icon={<Search size={18} />}
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            <motion.button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                selectedCategory === null
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              All
            </motion.button>
            {categories.map((category) => (
              <motion.button
                key={category.type}
                onClick={() => setSelectedCategory(category.type)}
                className={`px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                  selectedCategory === category.type
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category.icon} {category.label}
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {postsLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="h-96 bg-gray-200 dark:bg-gray-800 animate-pulse" />
            ))}
          </div>
        ) : filteredPosts.length > 0 ? (
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <PostCard post={post} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="text-center py-16">
            <Card className="max-w-md mx-auto">
              <div className="text-4xl mb-4">📝</div>
              <h3 className="text-xl font-bold mb-2">No posts found</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {searchTerm
                  ? 'Try a different search term'
                  : 'Be the first to share something'}
              </p>
              {user && (
                <Link href="/create">
                  <Button>Create a Post</Button>
                </Link>
              )}
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
