export type PostType = 'story' | 'poem' | 'quote' | 'thought';

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  bio?: string;
  role: 'user' | 'creator' | 'admin';
  createdAt: Date;
  updatedAt: Date;
  followersCount: number;
  followingCount: number;
  totalLikes: number;
}

export interface Post {
  id: string;
  authorId: string;
  author: Partial<User>;
  title: string;
  content: string;
  excerpt: string;
  type: PostType;
  category: string;
  imageUrl?: string;
  coverImage?: string;
  tags: string[];
  likes: number;
  comments: number;
  shares: number;
  views: number;
  createdAt: Date;
  updatedAt: Date;
  isPublished: boolean;
  isDraft?: boolean;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  author: Partial<User>;
  content: string;
  likes: number;
  replies: Comment[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Like {
  id: string;
  userId: string;
  postId: string;
  createdAt: Date;
}

export interface Follow {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: Date;
}

export interface Donation {
  id: string;
  donorId: string;
  creatorId: string;
  amount: number;
  currency: string;
  stripePaymentId: string;
  message?: string;
  createdAt: Date;
  status: 'pending' | 'completed' | 'failed';
}

export interface Notification {
  id: string;
  userId: string;
  type: 'like' | 'comment' | 'follow' | 'donation' | 'share';
  relatedUserId?: string;
  relatedPostId?: string;
  message: string;
  read: boolean;
  createdAt: Date;
}

export interface SearchResult {
  posts: Post[];
  users: Partial<User>[];
  tags: string[];
}
