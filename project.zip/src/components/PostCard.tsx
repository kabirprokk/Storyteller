'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Share2, Bookmark } from 'lucide-react';
import { Post } from '@/types';
import { formatTimeAgo, formatNumber, truncateText, getInitials } from '@/lib/utils';
import { Card } from '@/components/ui/Card';

interface PostCardProps {
  post: Post;
  onLike?: () => void;
  liked?: boolean;
  onBookmark?: () => void;
  bookmarked?: boolean;
}

export function PostCard({
  post,
  onLike,
  liked = false,
  onBookmark,
  bookmarked = false,
}: PostCardProps) {
  return (
    <Link href={`/post/${post.id}`}>
      <Card className="overflow-hidden cursor-pointer h-full">
        {post.coverImage && (
          <div className="relative w-full h-40 mb-4 -m-6 mb-6">
            <Image
              src={post.coverImage}
              alt={post.title}
              fill
              className="object-cover"
            />
          </div>
        )}

        <div className="space-y-3">
          {/* Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-sm font-bold">
              {getInitials(post.author.displayName || '')}
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
                {post.author.displayName}
              </h4>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {formatTimeAgo(post.createdAt)}
              </p>
            </div>
            <span className="px-2 py-1 text-xs font-medium bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full">
              {post.type}
            </span>
          </div>

          {/* Title and Excerpt */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white line-clamp-2 mb-2">
              {post.title}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
              {truncateText(post.excerpt || post.content, 120)}
            </p>
          </div>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              {post.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Stats and Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex gap-4 text-sm text-gray-500 dark:text-gray-400">
              <span className="flex items-center gap-1">
                <Heart size={16} /> {formatNumber(post.likes)}
              </span>
              <span className="flex items-center gap-1">
                <MessageCircle size={16} /> {formatNumber(post.comments)}
              </span>
              <span className="flex items-center gap-1">
                <Share2 size={16} /> {formatNumber(post.shares)}
              </span>
            </div>
            <motion.button
              onClick={(e) => {
                e.preventDefault();
                onBookmark?.();
              }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className={`p-2 rounded-lg transition-colors ${
                bookmarked
                  ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-600 dark:text-yellow-300'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400'
              }`}
            >
              <Bookmark size={18} fill={bookmarked ? 'currentColor' : 'none'} />
            </motion.button>
          </div>
        </div>
      </Card>
    </Link>
  );
}
