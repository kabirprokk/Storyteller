import {
  collection,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  getDoc,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  Query,
  QueryConstraint,
} from 'firebase/firestore';
import { db } from './firebase';
import { Post, User, Comment, Donation } from '@/types';

// Posts operations
export async function getPosts(
  constraints: QueryConstraint[] = [],
  pageLimit = 10
): Promise<Post[]> {
  try {
    const q = query(collection(db, 'posts'), ...constraints, limit(pageLimit));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Post[];
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
}

export async function getPostById(postId: string): Promise<Post | null> {
  try {
    const docRef = doc(db, 'posts', postId);
    const docSnapshot = await getDoc(docRef);

    if (!docSnapshot.exists()) return null;

    const data = docSnapshot.data();
    return {
      id: docSnapshot.id,
      ...data,
      createdAt: data.createdAt?.toDate(),
      updatedAt: data.updatedAt?.toDate(),
    } as Post;
  } catch (error) {
    console.error('Error fetching post:', error);
    throw error;
  }
}

export async function createPost(userId: string, postData: Partial<Post>): Promise<string> {
  try {
    const docRef = await addDoc(collection(db, 'posts'), {
      ...postData,
      authorId: userId,
      likes: 0,
      comments: 0,
      shares: 0,
      views: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      isPublished: false,
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating post:', error);
    throw error;
  }
}

export async function updatePost(postId: string, data: Partial<Post>): Promise<void> {
  try {
    const docRef = doc(db, 'posts', postId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: new Date(),
    });
  } catch (error) {
    console.error('Error updating post:', error);
    throw error;
  }
}

export async function deletePost(postId: string): Promise<void> {
  try {
    const docRef = doc(db, 'posts', postId);
    await deleteDoc(docRef);
  } catch (error) {
    console.error('Error deleting post:', error);
    throw error;
  }
}

// User operations
export async function getUserById(userId: string): Promise<User | null> {
  try {
    const docRef = doc(db, 'users', userId);
    const docSnapshot = await getDoc(docRef);

    if (!docSnapshot.exists()) return null;

    const data = docSnapshot.data();
    return {
      id: docSnapshot.id,
      ...data,
      createdAt: data.createdAt?.toDate(),
      updatedAt: data.updatedAt?.toDate(),
    } as User;
  } catch (error) {
    console.error('Error fetching user:', error);
    throw error;
  }
}

export async function createUser(userId: string, userData: Partial<User>): Promise<void> {
  try {
    const docRef = doc(db, 'users', userId);
    await updateDoc(docRef, {
      ...userData,
      role: 'user',
      followersCount: 0,
      followingCount: 0,
      totalLikes: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).catch(() => {
      // If user doesn't exist, create it
      return addDoc(collection(db, 'users'), {
        id: userId,
        ...userData,
        role: 'user',
        followersCount: 0,
        followingCount: 0,
        totalLikes: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    });
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
}

export async function updateUser(userId: string, data: Partial<User>): Promise<void> {
  try {
    const docRef = doc(db, 'users', userId);
    await updateDoc(docRef, {
      ...data,
      updatedAt: new Date(),
    });
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
}

// Search operations
export async function searchPosts(queryText: string, maxResults: number = 20): Promise<Post[]> {
  try {
    const q = query(
      collection(db, 'posts'),
      where('isPublished', '==', true),
      orderBy('createdAt', 'desc'),
      limit(maxResults)
    );
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs
      .map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          createdAt: data.createdAt?.toDate(),
          updatedAt: data.updatedAt?.toDate(),
        } as Post;
      })
      .filter((post) => post.title.toLowerCase().includes(queryText.toLowerCase()));
  } catch (error) {
    console.error('Error searching posts:', error);
    throw error;
  }
}

// Helper function for building queries
function buildQuery(collectionRef: any, ...constraints: QueryConstraint[]): Query {
  return query(collectionRef, ...constraints);
}

// Comments operations
export async function getPostComments(postId: string): Promise<Comment[]> {
  try {
    const q = query(
      collection(db, 'comments'),
      where('postId', '==', postId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    })) as Comment[];
  } catch (error) {
    console.error('Error fetching comments:', error);
    throw error;
  }
}

export async function addComment(postId: string, userId: string, content: string): Promise<string> {
  try {
    const docRef = await addDoc(collection(db, 'comments'), {
      postId,
      authorId: userId,
      content,
      likes: 0,
      replies: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    return docRef.id;
  } catch (error) {
    console.error('Error adding comment:', error);
    throw error;
  }
}

// Like operations
export async function toggleLike(postId: string, userId: string): Promise<void> {
  try {
    const q = query(
      collection(db, 'likes'),
      where('postId', '==', postId),
      where('userId', '==', userId)
    );
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      // Unlike
      await deleteDoc(doc(db, 'likes', querySnapshot.docs[0].id));
    } else {
      // Like
      await addDoc(collection(db, 'likes'), {
        postId,
        userId,
        createdAt: new Date(),
      });
    }
  } catch (error) {
    console.error('Error toggling like:', error);
    throw error;
  }
}

export async function isPostLikedByUser(postId: string, userId: string): Promise<boolean> {
  try {
    const q = query(
      collection(db, 'likes'),
      where('postId', '==', postId),
      where('userId', '==', userId)
    );
    const querySnapshot = await getDocs(q);
    return !querySnapshot.empty;
  } catch (error) {
    console.error('Error checking like:', error);
    throw error;
  }
}

// Follow operations
export async function toggleFollow(followerId: string, followingId: string): Promise<void> {
  try {
    const q = query(
      collection(db, 'follows'),
      where('followerId', '==', followerId),
      where('followingId', '==', followingId)
    );
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      // Unfollow
      await deleteDoc(doc(db, 'follows', querySnapshot.docs[0].id));
    } else {
      // Follow
      await addDoc(collection(db, 'follows'), {
        followerId,
        followingId,
        createdAt: new Date(),
      });
    }
  } catch (error) {
    console.error('Error toggling follow:', error);
    throw error;
  }
}

// Donation operations
export async function createDonation(donationData: Partial<Donation>): Promise<string> {
  try {
    const docRef = await addDoc(collection(db, 'donations'), {
      ...donationData,
      createdAt: new Date(),
      status: 'pending',
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating donation:', error);
    throw error;
  }
}

export async function getUserDonations(userId: string): Promise<Donation[]> {
  try {
    const q = query(
      collection(db, 'donations'),
      where('creatorId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);

    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
    })) as Donation[];
  } catch (error) {
    console.error('Error fetching donations:', error);
    throw error;
  }
}
