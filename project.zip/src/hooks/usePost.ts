import { useState, useCallback, useEffect } from 'react';
import { Post, Comment } from '@/types';
import * as firestoreUtils from '@/lib/firestore-utils';

export function usePosts(filters?: any) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadPosts = useCallback(async () => {
    try {
      setLoading(true);
      const data = await firestoreUtils.getPosts();
      setPosts(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load posts');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  return { posts, loading, error, refetch: loadPosts };
}

export function usePost(postId: string) {
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!postId) return;

    const loadPost = async () => {
      try {
        setLoading(true);
        const data = await firestoreUtils.getPostById(postId);
        setPost(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load post');
      } finally {
        setLoading(false);
      }
    };

    loadPost();
  }, [postId]);

  return { post, loading, error };
}

export function usePostComments(postId: string) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadComments = useCallback(async () => {
    if (!postId) return;

    try {
      setLoading(true);
      const data = await firestoreUtils.getPostComments(postId);
      setComments(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load comments');
    } finally {
      setLoading(false);
    }
  }, [postId]);

  useEffect(() => {
    loadComments();
  }, [loadComments]);

  return { comments, loading, error, refetch: loadComments };
}

export function useLike(postId: string, userId: string) {
  const [liked, setLiked] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkLike = async () => {
      try {
        const isLiked = await firestoreUtils.isPostLikedByUser(postId, userId);
        setLiked(isLiked);
      } finally {
        setLoading(false);
      }
    };

    checkLike();
  }, [postId, userId]);

  const toggleLike = useCallback(async () => {
    try {
      await firestoreUtils.toggleLike(postId, userId);
      setLiked(!liked);
    } catch (err) {
      console.error('Failed to toggle like:', err);
    }
  }, [postId, userId, liked]);

  return { liked, loading, toggleLike };
}
